<html>

<body>
    <p>
        This is test second view.
    </p>
</body>

</html>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Stark1 extends Controller
{
    public function tony($whatIsTony)
    {
        return "You can count on me";
    }
}

<html lang="en">
 <head>
  <meta charset="UTF-8">
  <title>
     Laravel
  </title>
  <style>
      *{
          text-align: center;
      }
  </style>
 </head>
 <body>
     <h3>This is blade template.</h3>
  <div class="welcome">
   <p>The route is {{ url('anyother/route') }}</p>
  </div>
 </body>
</html>

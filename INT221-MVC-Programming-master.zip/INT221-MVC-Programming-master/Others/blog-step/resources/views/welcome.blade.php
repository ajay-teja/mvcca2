<p>
    Welcome Again !!!
    {{$name}}. We are delighted to welcome you to our site again {{$name}}
</p>
<a href="/about"> About </a><br>
<a href="/user"> User  </a><br>
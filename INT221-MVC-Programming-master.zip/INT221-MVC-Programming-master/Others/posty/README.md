# Posty

The code for the Posty project, from the Traversy Media Laravel crash course.

Feel free to use this code however you like!

# Links

* [Codecourse](https://codecourse.com)
* [Traversy Media](https://www.youtube.com/user/TechGuyWeb)
